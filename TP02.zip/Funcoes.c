#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Cabecalho.h"

typedef struct info {
    char diretor[101]; //101 caracteres + 1 para fim de string
    char genero[51]; //50 caracteres + 1 para fim de string
    int ano;
    int faixaEtaria; // Use 0 para classificação livre
} Info;

typedef struct filme{
    char nome[101]; //100 caracteres + 1 para fim de string
    float preco; // Até duas casas decimais
    Info* informacoes; // Ponteiro para struct Info
} Filme;




//Função que cria e retorna um ponteiro simples para o tipo Filme
Filme* criar_filme(){
    Filme *f = malloc(sizeof(Filme));
    if(f == NULL)
        exit(1);

    f->informacoes = malloc(sizeof(Info));
    if(f->informacoes == NULL)
        exit(1);
    return f;

}

//Função que exclui um filme e libera memória
void free_filme(Filme* f){
    free(f);
}

//função que imprime informações de um filme
void imprimir_filme(Filme* f){
    printf("%.2f R$ || %s(%s, %d) || %s %d\n", f->preco, f->nome, f->informacoes->genero,  f->informacoes->faixaEtaria, f->informacoes->diretor, f->informacoes->ano);
}


//FUNÇÕES DE MANIPULAÇÃO
//função que acessa e modifica o nome de um filme
void set_nome(Filme* f, char* novo){
    strcpy(f->nome, novo);
}
//função que acessa e modifica o preço de um filme
void set_preco(Filme* f, float novo){
    f->preco = novo;
}
//função que acessa e renomeia um diretor de um filme
void set_diretor(Filme* f, char* novo){
    strcpy(f->informacoes->diretor, novo);
}
//função que acessa e renomeia os gêneros de um filme
void set_genero(Filme* f, char* novo){
    strcpy(f->informacoes->genero, novo);
}

//função que acessa e modifica o ano de um filme
void set_ano(Filme* f, int novo){
    f->informacoes->ano = novo;
}
//função que acessa e modifica a faixa etária de um filme
void set_faixaetaria(Filme* f, int novo){
    f->informacoes->faixaEtaria = novo;
}
