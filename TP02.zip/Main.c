#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Cabecalho.h"


//funcao que seta as informacoes do filme
void atribui_filme(Filme* tabela){
    char nome[101];
    float preco;
    char diretor[101];
    char genero[51]; 
    int ano;
    int faixaEtaria;
        
    printf("Nome: ");
    scanf("\n%[^\n]", nome);
    set_nome(tabela, nome);
    printf("Preco: ");
    scanf("%f", &preco);
    set_preco(tabela, preco);
    printf("Diretor: ");
    scanf("\n%[^\n]", diretor);
    set_diretor(tabela, diretor);
    printf("Ano: ");
    scanf("%d", &ano);
    set_ano(tabela, ano);
    printf("Genero: ");
    scanf("\n%[^\n]", genero);
    set_genero(tabela, genero);
    if(strstr (genero, "terror") || strstr(genero, "Terror")){
        printf("Faixa etaria: ");
        scanf("%d", &faixaEtaria);
        while(faixaEtaria < 18){
            printf("Filmes do genero Terror nao podem ter faixa etaria abaixo de 18\n");
            printf("Insira um valor valido:\n");
            scanf("%d", &faixaEtaria);
        }
        set_faixaetaria(tabela, faixaEtaria);
    }
    else{
        printf("Faixa etaria: ");
        scanf("%d", &faixaEtaria);
        set_faixaetaria(tabela, faixaEtaria);
    }
}

//funcao que printa menu
void menu(){
    printf("\n");
    printf("MENUS DE OPCOES: \n");
    printf("\n");
    printf("1 - CADASTRAR UM NOVO TITULO\n2 - ATUALIZAR INFO DE UM TITULO\n3 - EXCLUIR UM TITULO\n4 - FINALIZAR OPERACAO\n");
    printf("\n");
}

//funcao que imprime a tabela
void print_tabela(Filme** tabela, int tam){
    printf("-------------TABELA DE FILMES-------------\n\n");
    for(int i = 0; i < tam; i++){
        printf("%.4d -- ",i+1); //código de 4 caracteres
        imprimir_filme(tabela[i]);
    }
    menu();
}

//funcao que seta novo nome e diretor
void renomear_titulo(Filme** tabela, int codigo){
    char nome[101];
    char diretor[101];
    
    printf("Nome: ");
    scanf("\n%[^\n]", nome);
    set_nome(tabela[codigo-1], nome); //"codigo-1" seta a tabela na posicao correta
    printf("Diretor: ");
    scanf("\n%[^\n]", diretor);
    set_diretor(tabela[codigo-1], diretor); //"codigo-1" seta a tabela na posicao correta
}

//funcao que seta novo preco
void atualizar_preco(Filme** tabela, int codigo){
    float preco;
    
    printf("Preco: ");
    scanf("%f", &preco);
    set_preco(tabela[codigo-1], preco); //"codigo-1" seta a tabela na posicao correta
}

//funcao que seta novo genero
void atualizar_genero(Filme** tabela, int codigo){
    char genero[51];

    printf("Genero: ");
    scanf("\n%[^\n]", genero);
    set_genero(tabela[codigo-1], genero); //"codigo-1" seta a tabela na posicao correta
}


void excluir_titulo(Filme** tabela, int codigo, int* tam){
    int i;  //variavei que vai percorrer o vetor tabela
    free(tabela[codigo-1]); //libera a memoria no local do filme

/*nesse for eu vou arrastando o filme em questao para o final*/
    for(i = codigo-1; i<*tam-1; i++){
        tabela[i] = tabela[i+1];
    }
    *tam -=1; //tam diminui pois exclui o titulo
}

int main(void){
    /* variaveis: tamanho da tabela, opca de cadastro do menu principal, 
    opcao de cadastro do sub meno da opca 2*/
    int tam, opcao, opcao2, codigo; 
    Filme** tabela;

    printf("Entre com o tamanho da sua tabela: ");
    scanf("%d", &tam);
    tabela = malloc(tam * sizeof(Filme*)); //alocacao de memoria
    if(tabela == NULL){
        printf("Erro\n");
        exit(1);
    }
    for(int i = 0; i < tam; i++){
        tabela[i] = criar_filme(); //aloca o filme
        atribui_filme(tabela[i]); //seta o filme
    }
    printf("\n");
    print_tabela(tabela, tam);
    scanf("%d", &opcao);
    while(opcao != 4){ // o programa só para de rodar com a opcao 4
        if(opcao == 1){
            tabela = realloc(tabela, (tam+1) * sizeof(Filme*)); //realocao de memoria
            if(tabela == NULL){
                printf("Erro\n");
                exit(1);
            }
            tabela[tam] = criar_filme(); //aloca o filme
            atribui_filme(tabela[tam]); //seta o filme
            tam++; //aumento o tamanho pois adicionei mais um filme
        }
        else if(opcao == 2){
            printf("1 - RENOMEAR TITULO\n2 - ATUALIZAR PRECO\n3 - ATUALIZAR GENERO\n\n");
            scanf("%d", &opcao2);
            printf("Digite o codigo do filme: ");
            scanf("%d", &codigo);
            if(opcao2 == 1){
                renomear_titulo(tabela, codigo);
            }
            else if(opcao2 == 2){
                atualizar_preco(tabela, codigo);
            }
            else if(opcao2 == 3){
                atualizar_genero(tabela, codigo);
            }
            else{
                printf("Opcao invalida\n"); // caso digite numeros abaixo ou acima de 1 e 3
            }
        }
        else if(opcao == 3){
            printf("Digite o codigo do filme: ");
            scanf("%d", &codigo);
            excluir_titulo(tabela, codigo, &tam);
        }
        else{
            printf("Opcao invalida\n"); // caso digite numeros abaixo ou acima de 1 e 4
        }
        printf("\n");
        print_tabela(tabela, tam);
        scanf("%d", &opcao);
    }
    return 0;
}